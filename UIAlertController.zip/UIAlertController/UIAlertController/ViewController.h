//
//  ViewController.h
//  UIAlertController
//
//  Created by iOSDevBR on 06/03/17.
//  Copyright © 2017 iOSDevBR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *alertButton;
- (IBAction)alertButtonAction:(id)sender;

@end

