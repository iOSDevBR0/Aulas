//
//  AppDelegate.h
//  UIAlertController
//
//  Created by iOSDevBR on 06/03/17.
//  Copyright © 2017 iOSDevBR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

